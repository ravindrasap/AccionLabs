package empdetails;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Utility.Base;

public class Logindetailspage extends Base{

	protected WebDriver driver;
	
		
	public Logindetailspage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	//WebDriver driver = null;
	String projectpath = System.getProperty("user.dir");
	
	@Parameters("browserName")
	@BeforeTest
	public void setup(String browserName) {
		
    if(browserName.equalsIgnoreCase("chrome")){
				
    	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") +"//driver//"+"chromedriver.exe");
    	
    	driver = new ChromeDriver();
			
			
			System.out.println("launching chrome browser");
		
          }else if(browserName.equalsIgnoreCase("firefox")){
	
	     System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"//driver//"+"geckodriver.exe");
	    driver=new FirefoxDriver();
	 
		
      } else if(browserName.equalsIgnoreCase("Safari")){
	   System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"//driver//"+"Safari.exe");
	    driver = new SafariDriver();  
	}
       
	}
			
	@Test
	
	public void loginEnBrw () throws InterruptedException {
		
	Thread.sleep(1000);
				
    System.out.println("user lunch the url sucessfully");
		
							
			}
 
		
}
