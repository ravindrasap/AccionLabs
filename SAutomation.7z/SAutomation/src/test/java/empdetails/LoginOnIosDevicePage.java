package empdetails;
import java.net.URL;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class LoginOnIosDevicePage {
WebDriver driver;
DesiredCapabilities cap;
@Test
public void mobileTestIOS() throws Exception {
URL url = new URL("https://127.0.0.1:4723/wd/hub");
driver = new RemoteWebDriver(url,cap);
driver.get("https://www.lsac.org/lsat-prep-get-familiar");
System.out.println("Appium Test Started");
String title = driver.getTitle();
System.out.println("Title is- "+title);  
}
@BeforeMethod
public void beforeMethod() {
System.setProperty("webdriver.chrome.driver", "C:\\Appium\\76\\chromedriver.exe");	
cap = new DesiredCapabilities();
cap.setCapability("deviceName", "IPhone11");
cap.setCapability("udid", "d7206a48");
cap.setCapability("platformName", "IOS");
cap.setCapability("platformVersion", "9");
cap.setCapability(CapabilityType.BROWSER_NAME, "Chrome");
}
@AfterMethod
public void afterMethod() {
driver.close();
driver.quit();
}
}
//test