package Pageobject.java;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Utility.Base;
import empdetails.LoginOnDevicePage;
import empdetails.LoginOnIosDevicePage;
import empdetails.Logindetailspage;



  public class LoginOnIosDevice extends Base {
	@Test(priority=1)
	public void BasicDetailsonloginPage() throws Exception 
	{
		
		System.out.println("Driver valueE inside fillBasicDetailsPage() method is "+ driver);
		LoginOnIosDevicePage detailsPage = PageFactory.initElements(driver, LoginOnIosDevicePage.class);
		detailsPage.mobileTestIOS();
		// test	
	}

 
}
