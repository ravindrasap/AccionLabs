package Pageobject.java;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Utility.Base;
import empdetails.LoginOnDevicePage;
import empdetails.Logindetailspage;



  public class LoginOnDevice extends Base {
	@Test(priority=1)
	public void BasicDetailsonloginPage() throws Exception 
	{
		
		System.out.println("Driver valueE inside fillBasicDetailsPage() method is "+ driver);
		LoginOnDevicePage detailsPage = PageFactory.initElements(driver, LoginOnDevicePage.class);
		detailsPage.mobileTest();
				
	}

 
}
