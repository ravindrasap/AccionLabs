package Pageobject.java;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Utility.Base;
import empdetails.Logindetailspage;



  public class Logindetail extends Base {
	@Test(priority=1)
	public void BasicDetailsonloginPage() throws Exception 
	{
		
		System.out.println("Driver valueE inside fillBasicDetailsPage() method is "+ driver);
		Logindetailspage detailsPage = PageFactory.initElements(driver, Logindetailspage.class);
		detailsPage.loginEnBrw();
				// test
	}
	
}
