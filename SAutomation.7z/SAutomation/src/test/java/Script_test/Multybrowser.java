package Script_test;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Utility.Base;

public class Multybrowser extends Base {

	//String url = "https://www.google.com/";
	WebDriver driver = null;
	//String projectpath = System.getProperty("user.dir");
	
	@Parameters("browserName")
	@BeforeTest
	public void setup(String browserName) {
		
   if(browserName.equalsIgnoreCase("chrome")){
				
    	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") +"//driver//"+"chromedriver.exe");
    	driver = new ChromeDriver();
		System.out.println("launching chrome browser");
		
}if(browserName.equalsIgnoreCase("firefox")){
	
	System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"//driver//"+"geckodriver.exe");
	driver=new FirefoxDriver();
	System.out.println("launching firefox browser");
	
		
}
 if(browserName.equalsIgnoreCase("InternetExplorer")){
	
	//C:\\Users\\ravindrakumar\\Desktop\\IEDriverServer.exe"
	System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"//driver//"+"InternetExplorer.exe");
	driver=new InternetExplorerDriver();
	System.out.println("launching InternetExplorer browser");
	}
       
 
 
 if(browserName.equalsIgnoreCase("Safari")){
		
		//C:\\Users\\ravindrakumar\\Desktop\\IEDriverServer.exe"
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"//driver//"+"Safari.exe");
		driver=new SafariDriver();
		System.out.println("launching Safari browser");
		}
	}
	

	
}
